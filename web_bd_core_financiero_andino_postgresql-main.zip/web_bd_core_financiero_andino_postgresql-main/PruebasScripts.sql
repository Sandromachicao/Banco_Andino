-- ============================================================================
-- CONSULTA DE CREDENCIALES DE LOGIN  (bd_core_financiero)
-- ============================================================================
--
-- IMPORTANTE SOBRE LAS CONTRASEÑAS:
--
--   1) PERSONAL DEL BANCO (login :8001)
--      -> NO existe columna de contraseña en la tabla dpersonal.
--      -> La contraseña ES EL MISMO DNI (modo desarrollo): el backend valida
--         password == numerodni. Por eso abajo se muestra numerodni también
--         como columna "contrasena".
--
--   2) CLIENTES HOMEBANKING (login :8002)
--      -> SÍ existe columna password_hash en usuarios_homebanking, pero está
--         CIFRADA con bcrypt (irreversible): no se puede "leer" la clave original.
--      -> La contraseña real es 'demo1234' PARA TODOS los clientes.
--         Por eso abajo se muestra como literal 'demo1234'.
-- ============================================================================


-- ----------------------------------------------------------------------------
-- 1) PERSONAL DEL BANCO  (usuario + DNI)
--    Usuario = numerodni   |   Contraseña = el mismo numerodni
-- ----------------------------------------------------------------------------
SELECT
    p.codpersonal,
    p.numerodni                  AS usuario,
    p.numerodni                  AS contrasena,   -- clave = DNI (modo desarrollo)
    p.nombre
FROM dpersonal p
ORDER BY p.numerodni;


-- ----------------------------------------------------------------------------
-- 2) PERSONAL DEL BANCO  (con ROL/CARGO + contraseña)
--    El cargo se obtiene uniendo: dpersonal -> dpersonalcargo -> dcargopersonal
--    Contraseña = el mismo numerodni
-- ----------------------------------------------------------------------------
SELECT
    p.numerodni                  AS usuario,
    p.numerodni                  AS contrasena,   -- clave = DNI (modo desarrollo)
    cp.codcargopersonal          AS cod_cargo,
    cp.descargopersonal          AS cargo,
    p.nombre
FROM dpersonal p
LEFT JOIN dpersonalcargo pc ON pc.pkpersonal     = p.pkpersonal
LEFT JOIN dcargopersonal cp ON cp.pkcargopersonal = pc.pkcargopersonal
ORDER BY p.numerodni;

-- ----------------------------------------------------------------------------
-- 3) CLIENTES HOMEBANKING  (usuario + contraseña)
--    Usuario = username (codcliente en minúscula)
--    Contraseña = 'demo1234' para TODOS (en la tabla solo está el hash bcrypt)
-- ----------------------------------------------------------------------------
SELECT
    u.username                   AS usuario,
    'demo1234'                   AS contrasena,         -- clave real (igual para todos)
    u.password_hash              AS contrasena_cifrada, -- hash bcrypt guardado (irreversible)
    cl.codcliente,
    cl.numerodocumentoidentidad  AS dni_cliente,
    cl.nomcliente                AS nombre
FROM usuarios_homebanking u
JOIN dcliente cl ON cl.pkcliente = u.pkcliente
ORDER BY u.username;